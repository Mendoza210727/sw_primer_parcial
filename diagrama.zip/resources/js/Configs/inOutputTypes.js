const inOutputTypes = [
	"input",
	"output",
	"alternative output",
	"exception output"
]

export default inOutputTypes